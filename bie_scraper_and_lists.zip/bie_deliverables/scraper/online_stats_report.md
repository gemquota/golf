# Active Sites with Commission Statistics

| Site URL | Last Commission | Historical Avg | Total Value | Best Type |
| :--- | :--- | :--- | :--- | :--- |
| [https://onyxaud.com](https://onyxaud.com) | $0.00 | $200.00 | $200.00 | Airdrop Free 200⭐️ |
| [https://ozreel88.com](https://ozreel88.com) | $175.32 | $175.32 | $175.32 | COMMISSION |
| [https://ufo9.asia](https://ufo9.asia) | $66.19 | $38.52 | $77.03 | COMMISSION |
| [https://unitedau.com](https://unitedau.com) | $30.00 | $30.00 | $60.00 | SHARE BONUS |
| [https://avg88.com](https://avg88.com) | $36.00 | $36.00 | $36.00 | SHARE BONUS |
| [https://wombats88.com](https://wombats88.com) | $32.00 | $32.00 | $32.00 | SHARE BONUS |
| [https://aud33.com](https://aud33.com) | $20.00 | $15.42 | $30.84 | Weekly Affiliate |
| [https://mrpokies77.com](https://mrpokies77.com) | $0.00 | $30.00 | $30.00 | Downline 1st Deposit |
| [https://raabet9.com](https://raabet9.com) | $15.00 | $10.03 | $20.05 | Referral Bonus |
| [https://pokies4bet.com](https://pokies4bet.com) | $12.40 | $12.40 | $12.40 | COMMISSION |
| [https://panda95au.com](https://panda95au.com) | $10.00 | $5.69 | $11.38 | Downline Dep AUD20 |
| [https://candymommy.co](https://candymommy.co) | $10.00 | $10.00 | $10.00 | WEEKLY COMMISSION |
| [https://legit99.com](https://legit99.com) | $10.00 | $10.00 | $10.00 | New Share Bonus |
| [https://tab99au.com](https://tab99au.com) | $10.00 | $10.00 | $10.00 | Free Share Bonus |
| [https://wildspin24.com](https://wildspin24.com) | $0.00 | $10.00 | $10.00 | Downline Deposit $30 Get |
| [https://skygate9au.com](https://skygate9au.com) | $9.52 | $9.52 | $9.52 | COMMISSION |
| [https://bybid9.com](https://bybid9.com) | $9.00 | $9.00 | $9.00 | Referral Bonus |
| [https://ubet66aus.com](https://ubet66aus.com) | $9.00 | $9.00 | $9.00 | Referral Bonus |
| [https://auspay96.com](https://auspay96.com) | $8.63 | $8.63 | $8.63 | COMMISSION |
| [https://efa99aus.com](https://efa99aus.com) | $7.94 | $7.94 | $7.94 | COMMISSION |
| [https://vv88aud.io](https://vv88aud.io) | $7.56 | $7.56 | $7.56 | COMMISSION |
| [https://cbr8aus.com](https://cbr8aus.com) | $7.38 | $7.38 | $7.38 | COMMISSION |
| [https://weplay9aus.com](https://weplay9aus.com) | $6.99 | $6.99 | $6.99 | SHARE REFERRAL |
| [https://neolux.vip](https://neolux.vip) | $6.00 | $6.00 | $6.00 | <b style="color:#686A6C;">SHARE BONUS |
| [https://rubyaud.com](https://rubyaud.com) | $6.00 | $6.00 | $6.00 | SHARE BONUS |
| [https://gembetaus.com](https://gembetaus.com) | $5.88 | $5.88 | $5.88 | Referral Bonus |
| [https://1spinnwin.com](https://1spinnwin.com) | $5.12 | $5.12 | $5.12 | <b style="color:#4169e1;">WEEKLY COMMISSION |
| [https://kaboom77.com](https://kaboom77.com) | $5.00 | $5.00 | $5.00 | Share Bonus |
| [https://onya88.com](https://onya88.com) | $5.00 | $5.00 | $5.00 | Share & Invite Referral Link |
| [https://opera777.co](https://opera777.co) | $5.00 | $5.00 | $5.00 | Referral Share |
| [https://penguin88.club](https://penguin88.club) | $5.00 | $5.00 | $5.00 | SHARE BONUS |
| [https://spinking.co](https://spinking.co) | $5.00 | $5.00 | $5.00 | New Share Bonus |
| [https://topaz33.com](https://topaz33.com) | $0.00 | $3.30 | $3.30 | 2 Days Rebate |
| [https://bs22au.com](https://bs22au.com) | $0.00 | $3.17 | $3.17 | DAILY ROLLOVER REBATE |
| [https://win99aud.com](https://win99aud.com) | $0.00 | $3.00 | $3.00 | DOWNLINE DEPOSIT FREE |
| [https://thepokies96.com](https://thepokies96.com) | $0.00 | $2.50 | $2.50 | Winloss Rebate |
| [https://thepokies33.com](https://thepokies33.com) | $0.00 | $2.40 | $2.40 | Weekly Winlose Rebate 5% |
| [https://harbour33.com](https://harbour33.com) | $0.00 | $1.20 | $1.20 | 2 Days Rebate |
| [https://9au.com](https://9au.com) | $0.00 | $0.00 | $0.00 | Daily Free |
| [https://ausbet88.com](https://ausbet88.com) | $0.00 | $0.00 | $0.00 | LOSSCREDIT |
| [https://audgaming8.com](https://audgaming8.com) | $0.00 | $0.00 | $0.00 | Sharing Bonus |
| [https://astar77au.com](https://astar77au.com) | $0.00 | $0.00 | $0.00 | [INFO] Review & Win |
| [https://aud2u.com](https://aud2u.com) | $0.00 | $0.00 | $0.00 | MINI GAME: GOLDEN EGG 1 |
| [https://aus2u.com](https://aus2u.com) | $0.00 | $0.00 | $0.00 | SPECIAL 20$ TURNOVER X3 ONLY |
| [https://betzilla88.com](https://betzilla88.com) | $0.00 | $0.00 | $0.00 | Share Referral Rewards |
| [https://bonus96.com](https://bonus96.com) | $0.00 | $0.00 | $0.00 | $20 FREE $20 |
| [https://clubimperioaus.com](https://clubimperioaus.com) | $0.00 | $0.00 | $0.00 | Facebook Mission |
| [https://cr33au.com](https://cr33au.com) | $0.00 | $0.00 | $0.00 | <b style="color:#;">30Days Cash Challenge 10 |
| [https://eebet9.com](https://eebet9.com) | $0.00 | $0.00 | $0.00 | LOSSCREDIT PM REBATE |
| [https://enjoy96.com](https://enjoy96.com) | $0.00 | $0.00 | $0.00 | LUNAR daily free $8.8 |
| [https://ezaud.com](https://ezaud.com) | $0.00 | $0.00 | $0.00 | LUCKY DRAW |
| [https://nightclubaus.com](https://nightclubaus.com) | $0.00 | $0.00 | $0.00 | FREE SLOT BONUS I |
| [https://sm8aud.com](https://sm8aud.com) | $0.00 | $0.00 | $0.00 | SHARE FREE GAME |
| [https://southern9.com](https://southern9.com) | $0.00 | $0.00 | $0.00 | D-BOOST |
| [https://ubet96.com](https://ubet96.com) | $0.00 | $0.00 | $0.00 | VP Cash Back Bonus 1 |
| [https://v8au.com](https://v8au.com) | $0.00 | $0.00 | $0.00 | 2026 VIP DAILY FREE ( LOSS CREDIT ) |
| [https://vpower8.com](https://vpower8.com) | $0.00 | $0.00 | $0.00 | <b style="color:#df36ee;">♥️ 520 February ♥️ |
| [https://vip99.com](https://vip99.com) | $0.00 | $0.00 | $0.00 | POLAR PRIZE I |
| [https://weplay88.com](https://weplay88.com) | $0.00 | $0.00 | $0.00 | <B>New Register Free |
