import base
urls, creds = base.parse()
print(f"URLs: {len(urls)}")
print(f"Creds: {len(creds)}")
