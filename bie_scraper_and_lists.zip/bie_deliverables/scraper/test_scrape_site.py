import asyncio
import base
import net
import run
import logic
import flow
import threading
import queue
import datetime

async def test_single_site(url, username, password):
    base.setup()
    # Mock queues
    db_queue = queue.Queue()
    csv_queue = queue.Queue()
    
    # Start writer threads
    def db_writer():
        while True:
            item = db_queue.get()
            if item is None: break
            db_queue.task_done()
    def csv_writer():
        while True:
            item = csv_queue.get()
            if item is None: break
            print(f"CSV WRITE: {item}")
            csv_queue.task_done()
            
    threading.Thread(target=db_writer, daemon=True).start()
    threading.Thread(target=csv_writer, daemon=True).start()
    
    shared_stats = {'index': 0, 'successes': 0, 'failures': 0, 'total_bonuses': 0, 'new_bonuses': 0}
    locks = {'index': threading.Lock(), 'stats': threading.Lock()}
    
    worker = run.ScrapeWorker(0, [(url, username, password)], shared_stats, locks, 1, 0, False, None, [(username, password)], 1, db_queue, csv_queue)
    
    async with net.AsyncNetworkManager() as async_net:
        await worker.run_async(async_net)
    
    db_queue.put(None)
    csv_queue.put(None)
    print("Done testing single site.")

if __name__ == "__main__":
    import configparser
    config = configparser.ConfigParser()
    config.read('in/config/config.ini')
    # Get credentials for the username found in DB
    username = "61423349819"
    password = None
    for section in config.sections():
        if section.startswith('U'):
            u = config.get(section, 'username', fallback=config.get(section, 'u', fallback=None))
            if u == username:
                password = config.get(section, 'password', fallback=config.get(section, 'p', fallback=None))
                break
    
    if username and password:
        asyncio.run(test_single_site("https://ufo9.asia", username, password))
    else:
        print("Could not find credentials.")
